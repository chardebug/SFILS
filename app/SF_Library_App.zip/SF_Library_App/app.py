from flask import Flask, render_template, request, redirect
import mysql.connector
from config import DB_CONFIG

app = Flask(__name__)

def get_db():
    try:
        return mysql.connector.connect(**DB_CONFIG)
    except mysql.connector.Error as err:
        print(f"Database connection error: {err}")
        return None

@app.route('/')
def index():
    conn = get_db()
    if not conn:
        return "Failed to connect to database."
    cursor = conn.cursor(dictionary=True)
    cursor.execute("""
        SELECT record_id, patron_type_code, checkout_total
        FROM SF_Library_Data
        ORDER BY record_id DESC
        LIMIT 500
    """)
    rows = cursor.fetchall()
    cursor.close()
    conn.close()
    return render_template('index.html', rows=rows)

@app.route('/update', methods=['POST'])
def update():
    record_id = request.form.get('record_id')
    new_checkout = request.form.get('checkout_total')
    if not record_id or not new_checkout:
        return redirect('/')
    conn = get_db()
    if not conn:
        return "Failed to connect to database."
    cursor = conn.cursor()
    try:
        cursor.execute(
            "UPDATE SF_Library_Data SET checkout_total = %s WHERE record_id = %s",
            (new_checkout, record_id)
        )
        conn.commit()
    except mysql.connector.Error as err:
        print(f"Update error: {err}")
    finally:
        cursor.close()
        conn.close()
    return redirect('/')

if __name__ == '__main__':
    app.run(debug=True)
