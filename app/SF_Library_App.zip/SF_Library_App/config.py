DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': 'ENTERYOURPASSWORDHERE',
    'database': 'SF_LibraryDB',
    'port': 3306
}
