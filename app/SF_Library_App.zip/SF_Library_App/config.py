DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': 'yourpassword',
    'database': 'SF_LibraryDB',
    'port': 3306
}
