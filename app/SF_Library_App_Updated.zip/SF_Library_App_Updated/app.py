from flask import Flask, render_template, request, redirect
import mysql.connector
from config import DB_CONFIG

app = Flask(__name__)

def get_db():
    return mysql.connector.connect(**DB_CONFIG)

@app.route('/')
def index():
    conn = get_db()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("""
        SELECT
          p.patron_id,
          pt.patron_type_definition,
          p.checkout_total,
          p.home_library_code,
          CASE p.circulation_active_month
            WHEN 1 THEN 'January'
            WHEN 2 THEN 'February'
            WHEN 3 THEN 'March'
            WHEN 4 THEN 'April'
            WHEN 5 THEN 'May'
            WHEN 6 THEN 'June'
            WHEN 7 THEN 'July'
            WHEN 8 THEN 'August'
            WHEN 9 THEN 'September'
            WHEN 10 THEN 'October'
            WHEN 11 THEN 'November'
            WHEN 12 THEN 'December'
            ELSE 'Unknown'
          END AS circulation_active_month,
          p.year_patron_registered
        FROM patron p
        LEFT JOIN patronType pt ON p.patron_type_code = pt.patron_type_code
        ORDER BY p.patron_id DESC
        LIMIT 5000
    """)
    rows = cursor.fetchall()
    print("ROWS:", rows)
    cursor.close()
    conn.close()
    return render_template('index.html', rows=rows)

@app.route('/update', methods=['POST'])
def update():
    record_id = request.form.get('record_id')
    new_checkout = request.form.get('checkout_total')
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("UPDATE patron SET checkout_total = %s WHERE patron_id = %s", (new_checkout, record_id))
    conn.commit()
    cursor.close()
    conn.close()
    return redirect('/')

if __name__ == '__main__':
    app.run(debug=True)
